import { useState, useEffect } from 'react';
import { Toaster, toast } from 'sonner';
import Navbar from './sections/Navbar';
import Hero from './sections/Hero';
import Resources from './sections/Resources';
import Upload from './sections/Upload';
import Footer from './sections/Footer';
import './App.css';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('nianmeng_favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  // Save favorites to localStorage
  useEffect(() => {
    localStorage.setItem('nianmeng_favorites', JSON.stringify(favorites));
  }, [favorites]);

  const handleToggleFavorite = (id: string) => {
    setFavorites(prev => {
      const isFavorited = prev.includes(id);
      if (isFavorited) {
        toast.info('已取消收藏');
        return prev.filter(fav => fav !== id);
      } else {
        toast.success('已添加到收藏');
        return [...prev, id];
      }
    });
  };

  const handleBrowseClick = () => {
    document.getElementById('resources')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleUploadClick = () => {
    setIsUploadOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0f1011] text-white relative">
      {/* Noise overlay */}
      <div className="fixed inset-0 pointer-events-none z-50 noise-overlay opacity-30" />
      
      {/* Toast notifications */}
      <Toaster 
        position="top-center"
        toastOptions={{
          style: {
            background: 'rgba(15, 16, 17, 0.9)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            color: '#fff'
          }
        }}
      />

      {/* Navigation */}
      <Navbar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        favoriteCount={favorites.length}
        onUploadClick={handleUploadClick}
      />

      {/* Main Content */}
      <main>
        <Hero
          onBrowseClick={handleBrowseClick}
          onUploadClick={handleUploadClick}
        />
        
        <Resources
          searchQuery={searchQuery}
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
        />
        
        <Upload
          isOpen={isUploadOpen}
          onClose={() => setIsUploadOpen(false)}
        />
        
        <Footer />
      </main>
    </div>
  );
}

export default App;
