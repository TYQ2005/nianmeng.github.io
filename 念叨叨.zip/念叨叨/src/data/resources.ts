import type { Resource, Comment } from '@/types';

const mockComments: Comment[] = [
  {
    id: '1',
    author: '晴儿',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=xiaoming',
    content: '非常棒的资源，下载速度很快！',
    date: '2024-01-15',
    likes: 12
  },
  {
    id: '2',
    author: '设计师铖念',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=awei',
    content: '界面设计很精美，功能也很实用，推荐！',
    date: '2024-01-14',
    likes: 8
  },
  {
    id: '3',
    author: '程序员冰郁泪',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=xiaoli',
    content: '代码质量很高，学习了很多。',
    date: '2024-01-13',
    likes: 15
  }
];

export const resources: Resource[] = [
  {
    id: '1',
    title: 'PixelPerfect 设计工具',
    description: '一款强大的UI/UX设计工具，支持团队协作和实时预览，让设计工作更高效。',
    category: 'application',
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80',
    downloadCount: 12580,
    rating: 4.8,
    author: '设计工坊',
    uploadDate: '2024-01-10',
    fileSize: '156 MB',
    tags: ['设计', 'UI/UX', '团队协作'],
    comments: mockComments,
    isFavorite: false
  },
  {
    id: '2',
    title: 'CodeMaster IDE',
    description: '轻量级但功能强大的代码编辑器，支持多种编程语言和智能代码补全。',
    category: 'tool',
    image: 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&q=80',
    downloadCount: 8932,
    rating: 4.6,
    author: '开发者联盟',
    uploadDate: '2024-01-08',
    fileSize: '89 MB',
    tags: ['开发工具', 'IDE', '代码编辑'],
    comments: mockComments.slice(0, 2),
    isFavorite: false
  },
  {
    id: '3',
    title: 'DarkMode Pro 主题',
    description: '精美的深色模式主题包，适配多种应用和网站，保护眼睛的同时提升视觉体验。',
    category: 'theme',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80',
    downloadCount: 5621,
    rating: 4.5,
    author: '主题设计师',
    uploadDate: '2024-01-05',
    fileSize: '12 MB',
    tags: ['主题', '深色模式', 'UI'],
    comments: mockComments.slice(0, 1),
    isFavorite: false
  },
  {
    id: '4',
    title: 'AutoTask 插件',
    description: '自动化任务管理插件，帮助您简化工作流程，提高工作效率。',
    category: 'plugin',
    image: 'https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?w=800&q=80',
    downloadCount: 3420,
    rating: 4.3,
    author: '效率达人',
    uploadDate: '2024-01-03',
    fileSize: '8 MB',
    tags: ['插件', '自动化', '效率'],
    comments: [],
    isFavorite: false
  },
  {
    id: '5',
    title: 'PhotoEnhance Pro',
    description: 'AI驱动的图片增强工具，一键提升图片质量，支持批量处理。',
    category: 'application',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&q=80',
    downloadCount: 9876,
    rating: 4.7,
    author: 'AI实验室',
    uploadDate: '2024-01-02',
    fileSize: '234 MB',
    tags: ['图片处理', 'AI', '批量处理'],
    comments: mockComments,
    isFavorite: false
  },
  {
    id: '6',
    title: 'DevUtils 开发者工具箱',
    description: '一站式开发者工具集合，包含JSON格式化、Base64编解码、正则测试等实用工具。',
    category: 'tool',
    image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&q=80',
    downloadCount: 15432,
    rating: 4.9,
    author: '极客工具',
    uploadDate: '2023-12-28',
    fileSize: '45 MB',
    tags: ['开发工具', '工具箱', '实用工具'],
    comments: mockComments,
    isFavorite: false
  },
  {
    id: '7',
    title: 'Minimalist 图标包',
    description: '简约风格的矢量图标包，包含2000+精美图标，适用于各种设计项目。',
    category: 'theme',
    image: 'https://images.unsplash.com/photo-1618556450994-a6a128ef0d9d?w=800&q=80',
    downloadCount: 7654,
    rating: 4.4,
    author: '图标工坊',
    uploadDate: '2023-12-25',
    fileSize: '28 MB',
    tags: ['图标', '矢量', '设计资源'],
    comments: mockComments.slice(0, 2),
    isFavorite: false
  },
  {
    id: '8',
    title: 'VideoCompress 视频压缩',
    description: '高效的视频压缩工具，在保证质量的同时大幅减小文件体积。',
    category: 'application',
    image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&q=80',
    downloadCount: 4321,
    rating: 4.2,
    author: '视频处理专家',
    uploadDate: '2023-12-20',
    fileSize: '67 MB',
    tags: ['视频', '压缩', '媒体处理'],
    comments: mockComments.slice(0, 1),
    isFavorite: false
  }
];

export const categories = [
  { id: 'all', name: '全部', icon: 'LayoutGrid' },
  { id: 'application', name: '应用程序', icon: 'AppWindow' },
  { id: 'tool', name: '工具', icon: 'Wrench' },
  { id: 'theme', name: '主题', icon: 'Palette' },
  { id: 'plugin', name: '插件', icon: 'Puzzle' },
  { id: 'other', name: '其他', icon: 'MoreHorizontal' }
] as const;
