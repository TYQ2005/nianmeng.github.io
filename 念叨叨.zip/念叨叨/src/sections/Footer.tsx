import { Mail, MessageCircle, ExternalLink } from 'lucide-react';
// Footer component

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    {
      title: '导航',
      links: [
        { name: '首页', href: '#hero' },
        { name: '资源', href: '#resources' },
        { name: '上传', href: '#upload' }
      ]
    },
    {
      title: '关于',
      links: [
        { name: '关于我们', href: '#' },
        { name: '使用条款', href: '#' },
        { name: '隐私政策', href: '#' }
      ]
    },
    {
      title: '联系',
      links: [
        { name: '反馈意见', href: '#' },
        { name: '加入我们', href: '#' },
        { name: '商务合作', href: '#' }
      ]
    }
  ];

  const socialLinks = [
    { name: '微博', icon: 'M', href: '#' },
    { name: '哔哩哔哩', icon: 'B', href: '#' },
    { name: 'QQ', icon: 'Q', href: '#' }
  ];

  return (
    <footer
      id="footer"
      className="relative bg-[#0a0a0b] border-t border-white/5"
    >
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Brand & QR Code */}
          <div className="lg:col-span-2">
            {/* Logo */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-teal-400 flex items-center justify-center">
                <span className="text-white font-bold text-lg">念</span>
              </div>
              <span className="text-xl font-bold text-white">念萌社区</span>
            </div>

            <p className="text-gray-400 mb-6 max-w-sm">
              一个充满活力的资源分享社区，在这里发现、分享、下载最佳资源。
            </p>

            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 text-gray-400">
                <Mail className="w-5 h-5 text-blue-400" />
                <span>邮箱: 2326895769@qq.com</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <MessageCircle className="w-5 h-5 text-teal-400" />
                <span>腾讯频道: pd68049498</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-white/10 hover:text-white transition-all duration-300"
                  title={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((section) => (
            <div key={section.title}>
              <h4 className="text-white font-semibold mb-4">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="text-gray-400 hover:text-white transition-colors duration-300 flex items-center gap-1 group"
                    >
                      {link.name}
                      <ExternalLink className="w-3 h-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* QR Code Section */}
        <div className="mt-16 pt-8 border-t border-white/5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-center md:text-left">
              <h4 className="text-white font-semibold mb-2">加入腾讯频道</h4>
              <p className="text-gray-400 text-sm">
                扫描二维码或搜索频道号 <span className="text-blue-400">pd68049498</span> 加入我们
              </p>
            </div>
            
            {/* QR Code */}
            <div className="glass-card rounded-2xl p-4">
              <div className="w-40 h-40 rounded-xl overflow-hidden bg-white">
                <img
                  src="/qrcode.jpg"
                  alt="腾讯频道二维码"
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-center text-xs text-gray-500 mt-2">
                扫一扫加入频道
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">
              © {currentYear} 念萌社区. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm">
              Made with ❤️ by 念萌团队
            </p>
          </div>
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
    </footer>
  );
}
