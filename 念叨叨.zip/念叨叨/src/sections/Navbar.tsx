import { useState, useEffect } from 'react';
import { Search, Upload, User, Menu, X, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  favoriteCount: number;
  onUploadClick: () => void;
}

export default function Navbar({ searchQuery, onSearchChange, favoriteCount, onUploadClick }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: '首页', href: '#hero' },
    { name: '资源', href: '#resources' },
    { name: '上传', href: '#upload' },
    { name: '联系', href: '#footer' }
  ];

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-600 ease-expo',
        isScrolled
          ? 'py-2 px-4'
          : 'py-4 px-6'
      )}
    >
      <div
        className={cn(
          'mx-auto transition-all duration-600 ease-expo',
          isScrolled
            ? 'max-w-3xl glass rounded-full px-6 py-2'
            : 'max-w-7xl'
        )}
      >
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#hero"
            className="flex items-center gap-2 group"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-teal-400 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
              <span className="text-white font-bold text-sm">念</span>
            </div>
            <span className={cn(
              'font-semibold text-white transition-all duration-300',
              isScrolled ? 'text-sm' : 'text-base'
            )}>
              念萌社区
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm text-gray-300 hover:text-white transition-colors duration-300 relative group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-teal-400 transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Search */}
            <div className={cn(
              'hidden md:flex items-center transition-all duration-500 ease-expo overflow-hidden',
              isSearchExpanded ? 'w-64' : 'w-10'
            )}>
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="搜索资源..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  onFocus={() => setIsSearchExpanded(true)}
                  onBlur={() => !searchQuery && setIsSearchExpanded(false)}
                  className={cn(
                    'pl-9 pr-4 h-9 bg-white/5 border-white/10 text-white placeholder:text-gray-500 rounded-full transition-all duration-300',
                    isSearchExpanded ? 'w-full opacity-100' : 'w-10 opacity-0 cursor-pointer'
                  )}
                />
                {!isSearchExpanded && (
                  <button
                    onClick={() => setIsSearchExpanded(true)}
                    className="absolute left-0 top-0 w-10 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors"
                  >
                    <Search className="w-4 h-4 text-gray-400" />
                  </button>
                )}
              </div>
            </div>

            {/* Favorites */}
            <button className="relative p-2 rounded-full hover:bg-white/10 transition-colors">
              <Heart className="w-5 h-5 text-gray-300" />
              {favoriteCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-blue-500 to-teal-400 rounded-full text-xs text-white flex items-center justify-center font-medium">
                  {favoriteCount}
                </span>
              )}
            </button>

            {/* Upload Button */}
            <Button
              onClick={onUploadClick}
              size="sm"
              className="hidden md:flex items-center gap-2 bg-gradient-to-r from-blue-500 to-teal-400 hover:from-blue-600 hover:to-teal-500 text-white rounded-full px-4"
            >
              <Upload className="w-4 h-4" />
              <span>上传</span>
            </Button>

            {/* User */}
            <button className="p-2 rounded-full hover:bg-white/10 transition-colors">
              <User className="w-5 h-5 text-gray-300" />
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-gray-300" />
              ) : (
                <Menu className="w-5 h-5 text-gray-300" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-white/10">
            <div className="flex flex-col gap-4">
              {/* Mobile Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="搜索资源..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="pl-9 pr-4 h-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500 rounded-full w-full"
                />
              </div>

              {/* Mobile Links */}
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-gray-300 hover:text-white transition-colors py-2"
                >
                  {link.name}
                </a>
              ))}

              {/* Mobile Upload Button */}
              <Button
                onClick={() => {
                  onUploadClick();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full bg-gradient-to-r from-blue-500 to-teal-400 hover:from-blue-600 hover:to-teal-500 text-white rounded-full"
              >
                <Upload className="w-4 h-4 mr-2" />
                上传资源
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
