import { useState, useEffect, useRef } from 'react';
import { 
  Heart, 
  Download, 
  Star, 
  MessageCircle, 
  Search,
  LayoutGrid,
  AppWindow,
  Wrench,
  Palette,
  Puzzle,
  MoreHorizontal,
  Send,
  ThumbsUp,
  Calendar,
  User,
  FileArchive
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import type { Resource, Comment, Category } from '@/types';
import { resources as initialResources, categories } from '@/data/resources';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const categoryIcons: Record<string, React.ReactNode> = {
  LayoutGrid: <LayoutGrid className="w-4 h-4" />,
  AppWindow: <AppWindow className="w-4 h-4" />,
  Wrench: <Wrench className="w-4 h-4" />,
  Palette: <Palette className="w-4 h-4" />,
  Puzzle: <Puzzle className="w-4 h-4" />,
  MoreHorizontal: <MoreHorizontal className="w-4 h-4" />
};

interface ResourcesProps {
  searchQuery: string;
  favorites: string[];
  onToggleFavorite: (id: string) => void;
}

export default function Resources({ searchQuery, favorites, onToggleFavorite }: ResourcesProps) {
  const [resources, setResources] = useState<Resource[]>(initialResources);
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [newComment, setNewComment] = useState('');
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  // Filter resources
  const filteredResources = resources.filter(resource => {
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // GSAP animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Cards stagger animation
      gsap.fromTo(
        '.resource-card',
        { y: 100, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.05,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, [filteredResources]);

  const handleOpenDetail = (resource: Resource) => {
    setSelectedResource(resource);
    setIsDetailOpen(true);
  };

  const handleDownload = (resource: Resource) => {
    // Simulate download
    const updatedResources = resources.map(r => 
      r.id === resource.id ? { ...r, downloadCount: r.downloadCount + 1 } : r
    );
    setResources(updatedResources);
    if (selectedResource?.id === resource.id) {
      setSelectedResource({ ...resource, downloadCount: resource.downloadCount + 1 });
    }
    alert(`开始下载: ${resource.title}`);
  };

  const handleAddComment = () => {
    if (!newComment.trim() || !selectedResource) return;

    const comment: Comment = {
      id: Date.now().toString(),
      author: '我',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=me',
      content: newComment,
      date: new Date().toISOString().split('T')[0],
      likes: 0
    };

    const updatedResource = {
      ...selectedResource,
      comments: [...selectedResource.comments, comment]
    };

    setSelectedResource(updatedResource);
    setResources(resources.map(r => r.id === updatedResource.id ? updatedResource : r));
    setNewComment('');
  };

  const formatNumber = (num: number) => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + 'w';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k';
    }
    return num.toString();
  };

  return (
    <section
      id="resources"
      ref={sectionRef}
      className="relative py-24 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="text-white">热门</span>
            <span className="text-gradient">资源</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            探索社区精选的优质资源，从应用程序到设计工具，应有尽有
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id as Category)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300',
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-blue-500 to-teal-400 text-white'
                  : 'glass-card text-gray-400 hover:text-white hover:bg-white/5'
              )}
            >
              {categoryIcons[category.icon]}
              {category.name}
            </button>
          ))}
        </div>

        {/* Search hint */}
        {searchQuery && (
          <div className="flex items-center justify-center gap-2 mb-8 text-gray-400">
            <Search className="w-4 h-4" />
            <span>搜索结果: "{searchQuery}"</span>
            <span className="text-gray-500">({filteredResources.length} 个资源)</span>
          </div>
        )}

        {/* Resources Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {filteredResources.map((resource) => (
            <div
              key={resource.id}
              className="resource-card group relative glass-card rounded-2xl overflow-hidden hover-lift cursor-pointer"
              onClick={() => handleOpenDetail(resource)}
            >
              {/* Image */}
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={resource.image}
                  alt={resource.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f1011] via-transparent to-transparent opacity-60" />
                
                {/* Category badge */}
                <Badge className="absolute top-3 left-3 bg-white/10 backdrop-blur-sm text-white border-0">
                  {categories.find(c => c.id === resource.category)?.name}
                </Badge>

                {/* Favorite button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(resource.id);
                  }}
                  className="absolute top-3 right-3 p-2 rounded-full bg-black/30 backdrop-blur-sm transition-all duration-300 hover:bg-black/50"
                >
                  <Heart
                    className={cn(
                      'w-4 h-4 transition-colors',
                      favorites.includes(resource.id)
                        ? 'fill-red-500 text-red-500'
                        : 'text-white'
                    )}
                  />
                </button>
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="text-lg font-semibold text-white mb-2 line-clamp-1 group-hover:text-blue-400 transition-colors">
                  {resource.title}
                </h3>
                <p className="text-sm text-gray-400 mb-4 line-clamp-2">
                  {resource.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {resource.tags.slice(0, 2).map((tag, index) => (
                    <span
                      key={index}
                      className="text-xs px-2 py-1 rounded-full bg-white/5 text-gray-500"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Download className="w-4 h-4" />
                      {formatNumber(resource.downloadCount)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500" />
                      {resource.rating}
                    </span>
                  </div>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4" />
                    {resource.comments.length}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty state */}
        {filteredResources.length === 0 && (
          <div className="text-center py-20">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full glass-card flex items-center justify-center">
              <Search className="w-8 h-8 text-gray-500" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">未找到相关资源</h3>
            <p className="text-gray-400">尝试使用其他关键词或分类进行搜索</p>
          </div>
        )}
      </div>

      {/* Resource Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-[#0f1011] border-white/10 text-white">
          {selectedResource && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold">{selectedResource.title}</DialogTitle>
              </DialogHeader>

              <div className="grid md:grid-cols-2 gap-6 mt-4">
                {/* Left - Image & Info */}
                <div>
                  <div className="rounded-xl overflow-hidden mb-4">
                    <img
                      src={selectedResource.image}
                      alt={selectedResource.title}
                      className="w-full h-auto"
                    />
                  </div>

                  <div className="glass-card rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">作者</span>
                      <span className="text-white flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {selectedResource.author}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">上传日期</span>
                      <span className="text-white flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {selectedResource.uploadDate}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">文件大小</span>
                      <span className="text-white flex items-center gap-2">
                        <FileArchive className="w-4 h-4" />
                        {selectedResource.fileSize}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">下载次数</span>
                      <span className="text-white flex items-center gap-2">
                        <Download className="w-4 h-4" />
                        {formatNumber(selectedResource.downloadCount)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">评分</span>
                      <span className="text-white flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        {selectedResource.rating}
                      </span>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mt-4">
                    {selectedResource.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="bg-white/5 text-gray-300">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-3 mt-6">
                    <Button
                      onClick={() => handleDownload(selectedResource)}
                      className="flex-1 bg-gradient-to-r from-blue-500 to-teal-400 hover:from-blue-600 hover:to-teal-500 text-white"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      立即下载
                    </Button>
                    <Button
                      onClick={() => onToggleFavorite(selectedResource.id)}
                      variant="outline"
                      className={cn(
                        'border-white/20',
                        favorites.includes(selectedResource.id)
                          ? 'bg-red-500/20 border-red-500/50 text-red-400'
                          : 'text-white hover:bg-white/10'
                      )}
                    >
                      <Heart
                        className={cn(
                          'w-4 h-4',
                          favorites.includes(selectedResource.id) && 'fill-current'
                        )}
                      />
                    </Button>
                  </div>
                </div>

                {/* Right - Description & Comments */}
                <div>
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold mb-2">资源描述</h4>
                    <p className="text-gray-400 leading-relaxed">
                      {selectedResource.description}
                    </p>
                  </div>

                  {/* Comments */}
                  <div>
                    <h4 className="text-lg font-semibold mb-4">
                      评论 ({selectedResource.comments.length})
                    </h4>

                    {/* Comment list */}
                    <div className="space-y-4 mb-4 max-h-60 overflow-y-auto">
                      {selectedResource.comments.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">暂无评论，来发表第一条评论吧！</p>
                      ) : (
                        selectedResource.comments.map((comment) => (
                          <div key={comment.id} className="glass-card rounded-lg p-3">
                            <div className="flex items-start gap-3">
                              <img
                                src={comment.avatar}
                                alt={comment.author}
                                className="w-8 h-8 rounded-full"
                              />
                              <div className="flex-1">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-sm font-medium text-white">{comment.author}</span>
                                  <span className="text-xs text-gray-500">{comment.date}</span>
                                </div>
                                <p className="text-sm text-gray-400">{comment.content}</p>
                                <button className="flex items-center gap-1 mt-2 text-xs text-gray-500 hover:text-blue-400 transition-colors">
                                  <ThumbsUp className="w-3 h-3" />
                                  {comment.likes}
                                </button>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Add comment */}
                    <div className="flex gap-2">
                      <Textarea
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="写下你的评论..."
                        className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500 resize-none"
                        rows={2}
                      />
                      <Button
                        onClick={handleAddComment}
                        disabled={!newComment.trim()}
                        className="bg-blue-500 hover:bg-blue-600 text-white"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
