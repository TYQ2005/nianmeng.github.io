import { useState, useRef, useEffect } from 'react';
import { Upload as UploadIcon, X, File, Check, CloudUpload, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface UploadProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Upload({ isOpen, onClose }: UploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('application');
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const categories = [
    { id: 'application', name: '应用程序' },
    { id: 'tool', name: '工具' },
    { id: 'theme', name: '主题' },
    { id: 'plugin', name: '插件' },
    { id: 'other', name: '其他' }
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.upload-content',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files ? Array.from(e.target.files) : [];
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags(prev => [...prev, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(prev => prev.filter(tag => tag !== tagToRemove));
  };

  const handleUpload = async () => {
    if (!title.trim() || uploadedFiles.length === 0) return;

    setIsUploading(true);
    
    // Simulate upload
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsUploading(false);
    setUploadSuccess(true);
    
    // Reset after success
    setTimeout(() => {
      setUploadSuccess(false);
      setTitle('');
      setDescription('');
      setCategory('application');
      setTags([]);
      setUploadedFiles([]);
      onClose();
    }, 2000);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <>
      {/* Upload Section */}
      <section
        id="upload"
        ref={sectionRef}
        className="relative py-24 px-4 sm:px-6 lg:px-8"
      >
        {/* Background gradient */}
        <div className="absolute inset-0 gradient-mesh opacity-50" />
        
        <div className="upload-content relative max-w-4xl mx-auto">
          <div className="glass rounded-3xl p-8 sm:p-12">
            {/* Header */}
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/20 to-teal-400/20 border border-blue-500/30 mb-6">
                <Sparkles className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-blue-300">分享你的创作</span>
              </div>
              <h2 className="text-4xl sm:text-5xl font-bold mb-4">
                <span className="text-white">分享你的</span>
                <span className="text-gradient">资源</span>
              </h2>
              <p className="text-gray-400 max-w-xl mx-auto">
                为社区贡献你最好的作品，让更多人发现和使用你的创作
              </p>
            </div>

            {/* Upload Area */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('file-input')?.click()}
              className={cn(
                'relative border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300',
                isDragging
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-white/20 hover:border-white/40 hover:bg-white/5'
              )}
            >
              <input
                id="file-input"
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-500/20 to-teal-400/20 flex items-center justify-center">
                <CloudUpload className="w-10 h-10 text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                拖拽文件到此处
              </h3>
              <p className="text-gray-400 mb-4">
                或点击选择文件上传
              </p>
              <p className="text-sm text-gray-500">
                支持 ZIP, RAR, EXE, DMG 等格式，单个文件最大 500MB
              </p>
            </div>

            {/* File List */}
            {uploadedFiles.length > 0 && (
              <div className="mt-6 space-y-2">
                {uploadedFiles.map((file, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-xl bg-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <File className="w-5 h-5 text-blue-400" />
                      <div>
                        <p className="text-sm text-white">{file.name}</p>
                        <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFile(index)}
                      className="p-1 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <X className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Upload Button */}
            <div className="mt-8 text-center">
              <Button
                onClick={() => document.getElementById('file-input')?.click()}
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-teal-400 hover:from-blue-600 hover:to-teal-500 text-white rounded-full px-8"
              >
                <UploadIcon className="w-5 h-5 mr-2" />
                选择文件上传
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Upload Form Dialog */}
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[#0f1011] border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">上传资源</DialogTitle>
          </DialogHeader>

          {uploadSuccess ? (
            <div className="py-12 text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-green-500 to-teal-400 flex items-center justify-center animate-bounce">
                <Check className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">上传成功！</h3>
              <p className="text-gray-400">你的资源已成功提交，审核通过后将显示在列表中</p>
            </div>
          ) : (
            <div className="space-y-6 mt-4">
              {/* Title */}
              <div>
                <Label htmlFor="title" className="text-gray-300">资源标题 *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="给你的资源起个名字"
                  className="mt-2 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description" className="text-gray-300">资源描述</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="简要描述你的资源..."
                  className="mt-2 bg-white/5 border-white/10 text-white placeholder:text-gray-500 resize-none"
                  rows={4}
                />
              </div>

              {/* Category */}
              <div>
                <Label className="text-gray-300">分类</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setCategory(cat.id)}
                      className={cn(
                        'px-4 py-2 rounded-full text-sm transition-all duration-300',
                        category === cat.id
                          ? 'bg-gradient-to-r from-blue-500 to-teal-400 text-white'
                          : 'bg-white/5 text-gray-400 hover:bg-white/10'
                      )}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tags */}
              <div>
                <Label className="text-gray-300">标签</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addTag()}
                    placeholder="添加标签，按回车确认"
                    className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                  />
                  <Button
                    onClick={addTag}
                    variant="outline"
                    className="border-white/20 text-white hover:bg-white/10"
                  >
                    添加
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="bg-white/10 text-gray-300 flex items-center gap-1"
                    >
                      {tag}
                      <button
                        onClick={() => removeTag(tag)}
                        className="hover:text-white"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Files */}
              <div>
                <Label className="text-gray-300">上传的文件</Label>
                <div className="mt-2 space-y-2">
                  {uploadedFiles.length === 0 ? (
                    <div
                      onClick={() => document.getElementById('dialog-file-input')?.click()}
                      className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center cursor-pointer hover:border-white/40 hover:bg-white/5 transition-all"
                    >
                      <UploadIcon className="w-8 h-8 mx-auto mb-2 text-gray-500" />
                      <p className="text-sm text-gray-400">点击选择文件</p>
                    </div>
                  ) : (
                    uploadedFiles.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 rounded-xl bg-white/5"
                      >
                        <div className="flex items-center gap-3">
                          <File className="w-5 h-5 text-blue-400" />
                          <div>
                            <p className="text-sm text-white">{file.name}</p>
                            <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFile(index)}
                          className="p-1 rounded-full hover:bg-white/10 transition-colors"
                        >
                          <X className="w-4 h-4 text-gray-400" />
                        </button>
                      </div>
                    ))
                  )}
                  <input
                    id="dialog-file-input"
                    type="file"
                    multiple
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Submit */}
              <Button
                onClick={handleUpload}
                disabled={!title.trim() || uploadedFiles.length === 0 || isUploading}
                className="w-full bg-gradient-to-r from-blue-500 to-teal-400 hover:from-blue-600 hover:to-teal-500 text-white disabled:opacity-50"
              >
                {isUploading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    上传中...
                  </>
                ) : (
                  <>
                    <UploadIcon className="w-5 h-5 mr-2" />
                    确认上传
                  </>
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
