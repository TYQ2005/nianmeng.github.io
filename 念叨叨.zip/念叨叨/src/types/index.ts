export interface Resource {
  id: string;
  title: string;
  description: string;
  category: 'application' | 'tool' | 'theme' | 'plugin' | 'other';
  image: string;
  downloadCount: number;
  rating: number;
  author: string;
  uploadDate: string;
  fileSize: string;
  tags: string[];
  comments: Comment[];
  isFavorite?: boolean;
}

export interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  date: string;
  likes: number;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  email: string;
  uploadedResources: number;
  favorites: string[];
}

export type Category = 'all' | 'application' | 'tool' | 'theme' | 'plugin' | 'other';
